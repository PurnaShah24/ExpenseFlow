# ExpenseFlow - Architecture & Interview Preparation Guide
## For Campus Placement Assessment

---

## PART 1: APPLICATION ARCHITECTURE EXPLAINED

### 1.1 High-Level System Architecture

```
┌─────────────────────────────────────────────────────────┐
│          Browser (Client-Side Only)                      │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  ┌──────────────┐      ┌──────────────┐  ┌─────────────┐│
│  │ User Interface│      │ Application │  │   Storage   ││
│  │ (HTML/CSS)   │──────│   Logic      │──│  (Browser   ││
│  │              │      │   (JavaScript)  │  LocalStorage)
│  │ - Sidebar    │      │              │  │             ││
│  │ - Forms      │      │ - StorageService
│  │ - Tables     │      │ - UI Service │  │ ┌─────────┐ ││
│  │ - Modals     │      │ - Handlers   │  │ │ expenseClaims
│  │ - Charts     │      │              │  │ │ (JSON)   ││
│  └──────────────┘      └──────────────┘  │ └─────────┘ ││
│                                            └─────────────┘│
│  External Dependencies (CDN):                             │
│  - Bootstrap 5.3.2 (UI Framework)                         │
│  - Chart.js (Data Visualization)                          │
│  - Bootstrap Icons (Icon Set)                             │
│  - Google Fonts (Typography)                              │
│                                                           │
└─────────────────────────────────────────────────────────┘

NO BACKEND SERVER | NO DATABASE | 100% CLIENT-SIDE
```

### 1.2 Key Architectural Principles

✅ **Single Responsibility Pattern**
- **StorageService**: Only handles data persistence
- **UI**: Only handles view rendering
- **Handlers**: Only handles user events
- **AppState**: Only holds global application state

✅ **Data Flow Pattern**
```
User Action → Handlers → StorageService → UI Refresh
                ↓            ↓                ↓
           Event Listener  Save to Local   Render Updated
                          Storage           Views
```

✅ **Separation of Concerns**
- Data layer (StorageService)
- Presentation layer (UI)
- Controller layer (Handlers)

---

## PART 2: FILE STRUCTURE & PURPOSE

### Single HTML File Breakdown

```
expenseflow_corporate_expense_management_system.html
│
├─ HEAD Section (Lines 1-16)
│   ├─ Meta Tags (Charset, Viewport for Responsive)
│   ├─ Title & External Dependencies
│   └─ CDN Links (Bootstrap, Icons, Fonts, Chart.js)
│
├─ STYLE Section (Lines 17-144)
│   ├─ CSS Variables (Colors, Sidebar Width)
│   ├─ Component Styles (Sidebar, Cards, Badges)
│   ├─ Responsive Design (@media queries)
│   └─ Custom Classes (.stat-card, .badge-*, etc.)
│
├─ BODY HTML Section (Lines 146-1100)
│   │
│   ├─ Sidebar (Lines 149-200)
│   │   ├─ Brand Header
│   │   ├─ Role Selector Dropdown
│   │   └─ Navigation Links (5 main sections)
│   │
│   ├─ Main Content Area (Lines 202-1100)
│   │   ├─ Dashboard View (Statistics & Charts)
│   │   ├─ Submit Claim View (Form)
│   │   ├─ All Claims View (Searchable Table)
│   │   ├─ Approvals Queue View (Manager)
│   │   └─ Reimbursements Queue View (Finance)
│   │
│   └─ Modals (Lines 1060-1140)
│       ├─ Claim Details Modal
│       └─ Rejection Reason Modal
│
└─ JAVASCRIPT Section (Lines 1200-1391)
    │
    ├─ AppState Object (Global State)
    ├─ StorageService Object (Data Management)
    ├─ UI Object (View Rendering)
    ├─ Handlers Object (Event Management)
    └─ DOMContentLoaded Event (Initialization)
```

---

## PART 3: HOW LOCALSTORAGE WORKS IN THIS PROJECT

### 3.1 LocalStorage Basics

**What is LocalStorage?**
- Browser's built-in database (key-value pairs)
- Persists data even after browser closes
- Stores data as strings (we use JSON)
- Limited to ~5-10MB per domain

### 3.2 Implementation in ExpenseFlow

```javascript
// StorageService handles all localStorage operations

const StorageService = {
    KEY: 'expenseClaims',  // Key where data is stored
    
    getClaims() {
        // Retrieve claims from localStorage
        return JSON.parse(localStorage.getItem(this.KEY)) || [];
    },
    
    addClaim(claim) {
        // Add new claim and save
        const claims = this.getClaims();
        claims.push(claim);
        localStorage.setItem(this.KEY, JSON.stringify(claims));
    },
    
    updateClaimStatus(id, status, metadata) {
        // Update claim and persist
        const claims = this.getClaims();
        const claim = claims.find(c => c.id === id);
        if (claim) {
            claim.status = status;
            if (metadata) Object.assign(claim, metadata);
        }
        localStorage.setItem(this.KEY, JSON.stringify(claims));
    }
};
```

### 3.3 Data Flow with LocalStorage

```
Initial Load (First Visit)
↓
getClaims() → Empty array
↓
Use getDemoData() as fallback
↓
Display demo claims

User Submits Claim
↓
Handlers.init() → form submit event
↓
Create newClaim object
↓
StorageService.addClaim() → Writes to localStorage
↓
UI.refreshAll() → Reads from localStorage and renders

Browser Refresh (F5)
↓
DOMContentLoaded fires
↓
Handlers.init() + UI.refreshAll()
↓
StorageService.getClaims() → Reads from localStorage
↓
Data persists! ✅
```

### 3.4 LocalStorage Verification

**How to see localStorage in browser:**
```
1. Open DevTools (F12)
2. Go to "Application" tab
3. Expand "Local Storage"
4. Click on the current domain
5. Look for key: "expenseClaims"
6. Value is JSON array of claims
```

**Example localStorage content:**
```json
[
  {
    "id": "EXP-1234567890-123",
    "empName": "John Doe",
    "empId": "EMP-101",
    "category": "Travel",
    "amount": 15000,
    "date": "2024-01-15",
    "description": "Flight to Mumbai",
    "status": "Pending",
    "receipt": "",
    "rejectionReason": "",
    "reimbursedDate": ""
  }
]
```

---

## PART 4: APPROVAL WORKFLOW IMPLEMENTATION

### 4.1 Workflow State Diagram

```
┌─────────────────────────────────────────────────────────┐
│           EXPENSE CLAIM LIFECYCLE                        │
└─────────────────────────────────────────────────────────┘

                    ┌──────────────┐
                    │  Submitted   │
                    │  (Pending)   │
                    └──────┬───────┘
                           │
                ┌──────────┴──────────┐
                │                     │
                ▼                     ▼
        ┌─────────────┐       ┌──────────────┐
        │  Approved   │       │  Rejected    │
        │   (Ready)   │       │ (With Reason)│
        └──────┬──────┘       └──────────────┘
               │
               ▼
        ┌──────────────┐
        │ Reimbursed   │
        │ (Completed)  │
        └──────────────┘
```

### 4.2 Code Implementation of Workflow

#### Step 1: Employee Submits Claim
```javascript
// Location: Handlers.init() → form submit listener (Line 1230)
const newClaim = {
    id: newClaimId,
    ...
    status: 'Pending',  // ← Always starts as Pending
    rejectionReason: '',
    reimbursedDate: ''
};
StorageService.addClaim(newClaim);
```

#### Step 2: Manager Views Pending Claims
```javascript
// Location: UI.renderApprovalQueue() (Line 744)
const pendingClaims = claims.filter(c => c.status === 'Pending');
// Only Pending claims shown in approval queue
```

#### Step 3: Manager Approves or Rejects

**Approve Action:**
```javascript
// Location: Event delegation (Line 1280)
const approveBtn = e.target.closest('.approve-claim-btn');
if (approveBtn) {
    const id = approveBtn.getAttribute('data-id');
    StorageService.updateClaimStatus(id, 'Approved');
    // Status changes: Pending → Approved
}
```

**Reject Action:**
```javascript
// Location: Reject Modal (Line 1290)
// User must provide rejection reason
if (!reason) {
    errorEl.classList.remove('d-none');
    return; // Validation prevents empty rejection
}
StorageService.updateClaimStatus(id, 'Rejected', { 
    rejectionReason: reason 
});
// Status changes: Pending → Rejected with reason
```

#### Step 4: Finance Views Approved Claims
```javascript
// Location: UI.renderReimbursementQueue() (Line 783)
const approvedClaims = claims.filter(c => c.status === 'Approved');
// Only Approved claims shown in reimbursement queue
```

#### Step 5: Finance Reimburses Claim
```javascript
// Location: Event delegation (Line 1303)
const reimburseBtn = e.target.closest('.reimburse-claim-btn');
if (reimburseBtn) {
    const id = reimburseBtn.getAttribute('data-id');
    const today = new Date().toISOString().split('T')[0];
    StorageService.updateClaimStatus(id, 'Reimbursed', { 
        reimbursedDate: today 
    });
    // Status changes: Approved → Reimbursed
}
```

### 4.3 Business Rules Enforced

| Rule | Where Enforced | Code Line |
|------|---|---|
| New claims are Pending | StorageService.addClaim | 1234 |
| Only Pending claims shown in approval queue | UI filter | 744 |
| Rejection requires reason | Modal validation | 1320 |
| Only Approved claims shown in reimbursement | UI filter | 783 |
| Dashboard updates after every status change | UI.refreshAll() | 1241, 1285, 1310 |

---

## PART 5: IMPORTANT JAVASCRIPT FUNCTIONS

### 5.1 StorageService Functions

#### `getClaims()`
```javascript
getClaims: function() {
    return JSON.parse(localStorage.getItem(this.KEY)) || [];
}
```
**Purpose**: Retrieve all claims from browser storage
**Returns**: Array of claim objects
**Example**:
```javascript
const claims = StorageService.getClaims();
// Returns: [{ id: 'EXP-1001', ... }, { id: 'EXP-1002', ... }]
```

#### `addClaim(claim)`
```javascript
addClaim: function(claim) {
    const claims = this.getClaims();
    claims.push(claim);
    localStorage.setItem(this.KEY, JSON.stringify(claims));
}
```
**Purpose**: Add new expense claim and save to localStorage
**Parameters**: claim object with all details
**Example**:
```javascript
StorageService.addClaim({
    id: 'EXP-1234',
    empName: 'John',
    amount: 5000,
    status: 'Pending'
});
```

#### `updateClaimStatus(id, status, metadata)`
```javascript
updateClaimStatus: function(id, status, metadata = {}) {
    const claims = this.getClaims();
    const claim = claims.find(c => c.id === id);
    if (claim) {
        claim.status = status;
        if (metadata.rejectionReason) claim.rejectionReason = metadata.rejectionReason;
        if (metadata.reimbursedDate) claim.reimbursedDate = metadata.reimbursedDate;
        localStorage.setItem(this.KEY, JSON.stringify(claims));
    }
}
```
**Purpose**: Update claim status and optional metadata
**Parameters**:
- `id`: Claim ID to find
- `status`: New status (Approved, Rejected, Reimbursed)
- `metadata`: Additional data (rejection reason, reimbursement date)

### 5.2 UI Functions

#### `renderDashboardStats()`
**Purpose**: Calculate and display dashboard statistics
**What it does**:
- Calculates total claimed amount
- Counts pending, approved, reimbursed claims
- Updates stat card values

**Example calculation**:
```javascript
const totalSpent = claims.reduce((sum, c) => sum + c.amount, 0);
// Sum all claim amounts
// Example: 15000 + 2500 + 5000 = 22500
```

#### `renderAllClaimsTable(claims)`
**Purpose**: Display filtered claims in table format
**Filtering logic**:
```javascript
let filtered = claims.filter(claim => {
    const matchesSearch = claim.id.toLowerCase().includes(searchTerm);
    const matchesCategory = filterCategory === 'ALL' || claim.category === filterCategory;
    const matchesStatus = filterStatus === 'ALL' || claim.status === filterStatus;
    return matchesSearch && matchesCategory && matchesStatus;
});
```
**Supports**: Search by ID, filter by category, filter by status

#### `showClaimDetails(id)`
**Purpose**: Display claim details in a modal popup
**What it does**:
- Finds claim by ID
- Formats all claim information
- Shows rejection reason (if rejected)
- Shows receipt image (if uploaded)

#### `showToast(message, type)`
**Purpose**: Display temporary notification
**Parameters**:
- `message`: Text to display
- `type`: 'success', 'danger', or 'info' (affects color)
**Example**:
```javascript
UI.showToast('Claim #EXP-1001 approved!', 'success');
```

### 5.3 Handler Functions

#### `switchTab(targetViewId)`
**Purpose**: Switch between different sections (Dashboard, Submit, Approvals, etc.)
**What it does**:
1. Update active sidebar link
2. Hide all sections
3. Show target section
4. Update page title
5. Refresh UI data

**Sections**:
- `dashboard-view`: Dashboard with stats
- `submit-view`: Form to submit new claim
- `claims-view`: Table of all claims
- `approvals-view`: Manager approval queue
- `reimbursements-view`: Finance reimbursement queue

---

## PART 6: BUSINESS RULES & ASSUMPTIONS

### 6.1 Core Business Rules (Verified & Working)

| # | Rule | Implementation | Status |
|---|------|---|---|
| 1 | New claims must start as Pending | Line 1234: `status: 'Pending'` | ✅ |
| 2 | Only Pending claims can be approved/rejected | Lines 744, 1280: Filter by status | ✅ |
| 3 | Rejected claims must have reason | Lines 1320-1323: Validation | ✅ |
| 4 | Only Approved claims can be reimbursed | Lines 783, 1303: Filter by status | ✅ |
| 5 | Claim IDs must be unique | Line 1224: Date.now() + random | ✅ Fixed |
| 6 | Dashboard totals must update immediately | Line 1241: UI.refreshAll() | ✅ |
| 7 | Data persists after browser refresh | localStorage persistence | ✅ |

### 6.2 Current Assumptions

**✅ Single User/No Authentication**
```javascript
// Role selector in sidebar lets any user switch roles
// Assumes single user testing the application
// In production, would require login backend
```

**✅ All Claims Visible to All Roles**
```javascript
// Finance can see all claims, not just their department
// No role-based data hiding
// Good for demo, would change in production
```

**✅ No Backend**
```javascript
// All data stored in browser's localStorage
// Data doesn't sync across browsers or devices
// Perfect for portfolio/assessment project
```

**✅ No File Storage**
```javascript
// Receipt images stored as base64 in localStorage
// Works for small images (<500KB)
// Would need external storage (S3, Firebase) in production
```

**✅ Demo Data Always Available**
```javascript
// If localStorage empty, shows demo claims
// Allows fresh start without manual data entry
getDemoData: function() {
    return [
        { id: 'EXP-1001', ... },  // Sample claims
        ...
    ];
}
```

---

## PART 7: LIMITATIONS OF CURRENT MVP

### 7.1 Architectural Limitations

❌ **No User Authentication**
- Anyone can access any role
- No login system
- No audit trail of who did what

❌ **No Backend Server**
- Data only lives in this browser
- Can't share data with other users
- Can't access from different device

❌ **No Real Database**
- localStorage limited to 5-10MB
- Unstructured data (just JSON array)
- No query capabilities

❌ **No File Storage**
- Receipt images limited to small sizes
- Stored in localStorage (inefficient)
- No proper file management

### 7.2 Feature Limitations

❌ **No Notification System**
- No email alerts
- No in-app notifications for status changes
- Manager doesn't know when claim arrives

❌ **No Audit History**
- Can't see who approved/rejected when
- No email trail
- Can't recover rejected claims

❌ **No Advanced Reporting**
- Can't generate Excel reports
- Can't export to PDF
- Limited to basic charts

❌ **No Advanced Filtering**
- Can't filter by date range
- Can't filter by approval time
- Can't see claims trending

❌ **No Business Logic**
- No budget limits per employee
- No category spending caps
- No duplicate expense detection

### 7.3 Performance Limitations

❌ **All Data in Memory**
- Large number of claims (~10,000+) might slow down
- No pagination implemented
- Table renders all claims

❌ **No Caching**
- Charts recalculated every refresh
- No lazy loading
- All data loaded at once

---

## PART 8: FUTURE IMPROVEMENTS (Phase 2+)

### Phase 2: Backend Integration
```javascript
// Instead of localStorage, use API:
// POST /api/claims → Submit new claim
// GET /api/claims → Get all claims
// PUT /api/claims/{id} → Update status
// Authentication & authorization
// Real database (PostgreSQL, MongoDB)
```

### Phase 3: Advanced Features
```javascript
// - Email notifications (nodemailer)
// - PDF generation (pdfkit)
// - Excel export (xlsx)
// - Advanced charts (D3.js, Recharts)
// - Audit logging (Winston)
// - File storage (AWS S3, Google Cloud Storage)
```

### Phase 4: Scalability
```javascript
// - Microservices architecture
// - API Gateway (Kong, AWS API Gateway)
// - Message Queue (RabbitMQ, Kafka)
// - Cache layer (Redis)
// - CDN for static files (Cloudflare)
```

### Phase 5: Enterprise Features
```javascript
// - Multi-tenant support
// - Advanced RBAC (Role-Based Access Control)
// - Department budgeting
// - Compliance reporting (SOX, GDPR)
// - Mobile app (React Native, Flutter)
```

---

## PART 9: TESTING CHECKLIST FOR INTERVIEWS

### Manual Testing Scenarios

**Test 1: Submit Claim & Verify Status**
```
1. Click "Submit Claim"
2. Fill form (Name, ID, Amount, Category, Date)
3. Click "Submit Claim"
✓ Claim shows in "All Claims" with "Pending" status
✓ Dashboard "Pending Review" count increases
✓ Toast notification shows success
```

**Test 2: Approve Claim in Manager View**
```
1. Switch to "Manager View" (role selector)
2. Click "Approvals (Manager)"
3. Click "Approve" button
✓ Claim disappears from approval queue
✓ Claim appears in "Reimbursement (Finance)" queue
✓ Dashboard "Approved Amount" increases
```

**Test 3: Reject Claim with Reason**
```
1. Switch to "Manager View"
2. Click "Approvals (Manager)"
3. Click "Reject" button
4. Enter rejection reason (e.g., "Budget exceeded")
5. Click "Confirm Rejection"
✓ Modal closes
✓ Claim shows "Rejected" status in All Claims
✓ Rejection reason visible in claim details
```

**Test 4: Reimburse Approved Claim**
```
1. Switch to "Finance" view
2. Click "Reimbursements (Finance)"
3. Click "Reimburse" button
✓ Claim status changes to "Reimbursed"
✓ "Reimbursed" amount updates on dashboard
✓ Claim disappears from reimbursement queue
```

**Test 5: Verify Browser Persistence**
```
1. Submit a new claim
2. Verify it appears in All Claims
3. Press F5 (refresh browser)
✓ Claim still exists after refresh
✓ All previous data persists
✓ localStorage key visible in DevTools
```

**Test 6: Search & Filter**
```
1. Go to "All Claims"
2. Type claim ID in search box
✓ Table filters in real-time
3. Change category filter
✓ Only claims from selected category shown
4. Click "Clear" button
✓ All filters reset
```

---

