# ExpenseFlow - 10 Technical Interview Questions
## Campus Placement Assessment Interview Prep

---

## Question 1: How Does LocalStorage Work in Your Application?

### Interview Question
*"Can you explain how you're using browser localStorage in your expense management system? How does data persist when users refresh the page?"*

### Suggested Answer

**LocalStorage Basics:**
LocalStorage is a browser API that stores key-value pairs as strings. It persists data even after the browser closes. I use it as my database for this project.

**Implementation in ExpenseFlow:**
```javascript
// StorageService manages all storage operations
const StorageService = {
    KEY: 'expenseClaims',  // Unique key
    
    // Get all claims from storage
    getClaims: function() {
        return JSON.parse(localStorage.getItem(this.KEY)) || [];
    },
    
    // Add new claim
    addClaim: function(claim) {
        const claims = this.getClaims();
        claims.push(claim);
        localStorage.setItem(this.KEY, JSON.stringify(claims));
    }
};
```

**Data Persistence Flow:**
1. User submits a claim → `StorageService.addClaim()` is called
2. Claims array is retrieved, new claim added
3. `JSON.stringify()` converts array to string
4. Data saved to localStorage with key 'expenseClaims'
5. User refreshes page → Data still there!
6. On page load, `getClaims()` retrieves stored data automatically

**Why It Works:**
- Browser stores data locally on the device
- Data survives browser restart
- Only cleared when user clears browser cache
- Perfect for a beginner project without a backend

**Limitations I'm Aware Of:**
- Limited to ~5-10MB per domain
- Only works on same device/browser
- Not suitable for multi-user systems
- No built-in sync capability

---

## Question 2: Explain Your Approval Workflow - How Does a Claim Move from Pending to Reimbursed?

### Interview Question
*"Walk me through the complete lifecycle of an expense claim. What are the different statuses and who can perform each action?"*

### Suggested Answer

**Claim Lifecycle (4 Statuses):**
```
Pending → Approved → Reimbursed  (Happy Path)
        ↘ Rejected              (Sad Path)
```

**Status Progression Details:**

**1. PENDING (Employee Creates)**
```javascript
// User fills form and clicks Submit
const newClaim = {
    id: 'EXP-' + Date.now() + '-' + Math.random(),
    status: 'Pending',           // ← Always starts here
    empName: 'John',
    amount: 5000,
    rejectionReason: '',          // Empty initially
    reimbursedDate: ''            // Empty initially
};
```
- Only employees can create claims
- Automatically set to "Pending"
- Shows in Manager's "Approvals" queue

**2. APPROVAL (Manager Reviews)**
```javascript
// Manager sees only Pending claims:
const pendingClaims = claims.filter(c => c.status === 'Pending');

// Manager has 2 choices:

// Choice A: APPROVE
StorageService.updateClaimStatus(claimId, 'Approved');
// Status: Pending → Approved
// Shows in Finance's "Reimbursement" queue

// Choice B: REJECT (requires reason)
const reason = "Budget exceeded for this quarter";
StorageService.updateClaimStatus(claimId, 'Rejected', { 
    rejectionReason: reason 
});
// Status: Pending → Rejected
// Shows in All Claims with rejection reason
```

**3. REIMBURSEMENT (Finance Processes)**
```javascript
// Finance sees only Approved claims:
const approvedClaims = claims.filter(c => c.status === 'Approved');

// Finance clicks Reimburse button:
const today = new Date().toISOString().split('T')[0];
StorageService.updateClaimStatus(claimId, 'Reimbursed', { 
    reimbursedDate: today 
});
// Status: Approved → Reimbursed
// Claim disappears from reimbursement queue
// Shows completed in All Claims
```

**Business Rules Enforced:**
- ✅ New claims MUST start as Pending (line 1234)
- ✅ Only Pending claims shown to Manager (line 744)
- ✅ Manager MUST provide rejection reason (line 1320 validation)
- ✅ Only Approved claims shown to Finance (line 783)
- ✅ Dashboard updates instantly (line 1285)

**How I Verified This Works:**
- Tested by manually going through each step
- Checked dashboard totals update correctly
- Verified data persists after refresh
- Confirmed rejected claims show reason in details modal

---

## Question 3: What's the Difference Between Your Role Selector and Real Authentication?

### Interview Question
*"I notice you have a role selector (Employee, Manager, Finance) in your application. Why doesn't this provide real security?"*

### Suggested Answer

**Current Implementation (Role Selector):**
```html
<select id="role-selector" class="form-select">
    <option value="Employee">Employee View</option>
    <option value="Manager">Manager View</option>
    <option value="Finance">Finance View</option>
</select>
```

**The Problem:**
This is a UI selector, NOT authentication:
- Anyone can switch roles with one click
- No login required
- No verification of identity
- No audit trail of who did what
- Different browsers/devices = different data

**Real Authentication Would Look Like:**
```javascript
// What REAL authentication needs:
// 1. Login form with username/password
// 2. Server validates credentials against database
// 3. Server creates session token
// 4. Token sent with every request
// 5. Server verifies token before allowing action
// 6. Log who performed each action
// 7. Different data per user/department

// Example (pseudo-code):
const loginUser = async (email, password) => {
    const response = await fetch('/api/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
    });
    const { token, userId } = await response.json();
    localStorage.setItem('authToken', token);
    // Now request API with this token
};
```

**Why I Did It This Way:**
- This is a beginner project for portfolio
- Demonstrating authentication system would require:
  - Backend server (Node.js, Python, Java)
  - Database (PostgreSQL, MongoDB)
  - Password hashing (bcrypt)
  - Session management
  - This complexity is beyond beginner level
  
**What I'm Showing Instead:**
- How role-based UI changes work
- Different views for different roles
- Data persistence with localStorage
- Frontend filtering logic

**In Production, I Would Add:**
- User login with authentication
- Backend API to validate requests
- Role-based access control (RBAC)
- Audit logging of all actions
- Encryption for sensitive data

---

## Question 4: Why Did You Use Date.now() for Generating Claim IDs?

### Interview Question
*"Looking at your code, I see you generate claim IDs as `'EXP-' + Date.now() + '-' + Math.random()`. Why is this better than just a simple random number?"*

### Suggested Answer

**The Problem I Solved:**
In my original code, I used simple random numbers:
```javascript
// BAD: Simple random number
const claimId = 'EXP-' + Math.floor(1000 + Math.random() * 9000);
// Example: EXP-5423

// Problem: Two claims submitted at ALMOST the same time
// Could generate: EXP-5423 and EXP-5423 (DUPLICATE!)
```

**Why This Is Dangerous:**
```javascript
// Claim 1
Math.random() * 9000 = 5423.123...  → EXP-5423

// Claim 2 (submitted millisecond later)
Math.random() * 9000 = 5423.789...  → EXP-5423  // DUPLICATE!

// Now we have two claims with same ID
// Database queries break
// User can't find correct claim
```

**My Solution Using Date.now():**
```javascript
const claimId = 'EXP-' + Date.now() + '-' + Math.floor(Math.random() * 1000);

// Example: EXP-1695894567892-342

// Why this works:
// Date.now() returns milliseconds since 1970
// Example: 1695894567892
// 
// Two claims CANNOT have same timestamp
// (unless in exact same millisecond - extremely rare)
// Even if they do, we add random number (0-999) for extra safety
//
// Result: Virtually impossible to get duplicates
```

**Comparison:**

| Method | Range | Uniqueness | Risk |
|---|---|---|---|
| Simple Random (1-9999) | 9000 options | 1 in 9000 chance of duplicate | ❌ HIGH |
| Date.now() | 13 digits (trillions) | Each millisecond unique | ✅ ZERO |
| Date.now() + Random | 13 digits + 3 digits | Same millisecond fallback | ✅ ZERO |

**Real-World Example:**
```javascript
// Timestamp-based is more reliable
const now = Date.now();
// Returns: 1704064234567 (unique per millisecond)

// Even if 2 claims submitted in same millisecond:
// EXP-1704064234567-342
// EXP-1704064234567-789
// Different random suffixes prevent collision
```

**What I Learned:**
- Distributed systems need unique IDs
- Random alone is not enough for high-volume systems
- Timestamp is more reliable than randomness
- Combining both gives best of both worlds

---

## Question 5: How Do You Calculate Dashboard Statistics? Walk Me Through One Example.

### Interview Question
*"Your dashboard shows statistics like 'Total Claimed', 'Pending Review', 'Approved Amount'. Can you explain exactly how these are calculated?"*

### Suggested Answer

**Dashboard Statistics Code:**
```javascript
renderDashboardStats: function() {
    const claims = StorageService.getClaims();
    
    // Stat 1: Total Claimed Amount (all claims, any status)
    const totalSpent = claims.reduce((sum, c) => sum + c.amount, 0);
    
    // Stat 2: Pending Count (how many waiting for approval)
    const pending = claims.filter(c => c.status === 'Pending').length;
    
    // Stat 3: Approved Amount (approved OR reimbursed)
    const approvedAmount = claims
        .filter(c => c.status === 'Approved' || c.status === 'Reimbursed')
        .reduce((sum, c) => sum + c.amount, 0);
    
    // Stat 4: Reimbursed Amount (fully processed)
    const reimbursedAmount = claims
        .filter(c => c.status === 'Reimbursed')
        .reduce((sum, c) => sum + c.amount, 0);
    
    // Update display
    document.getElementById('stat-total-claimed').innerText = 
        '₹' + totalSpent.toFixed(2);
}
```

**Let Me Walk Through With Real Example:**

**Sample Data in Storage:**
```javascript
[
    { id: 'EXP-1001', amount: 15000, status: 'Reimbursed' },
    { id: 'EXP-1002', amount: 2500,  status: 'Approved' },
    { id: 'EXP-1003', amount: 5000,  status: 'Pending' },
    { id: 'EXP-1004', amount: 8000,  status: 'Rejected' }
]
```

**Step-by-Step Calculation:**

**1. Total Claimed (Sum of ALL amounts):**
```
reduce((sum, claim) => sum + claim.amount, 0)
= 0 + 15000 + 2500 + 5000 + 8000
= 30,500 ₹
```

**2. Pending Count (Count of status='Pending'):**
```
filter(c => c.status === 'Pending').length
= [{ id: 'EXP-1003', ... }].length
= 1
```
(Only EXP-1003 is pending)

**3. Approved Amount (Sum of 'Approved' or 'Reimbursed'):**
```
filter(c => c.status === 'Approved' || c.status === 'Reimbursed')
= [
    { amount: 15000, status: 'Reimbursed' },  ← Include
    { amount: 2500,  status: 'Approved' }     ← Include
]
.reduce((sum, c) => sum + c.amount, 0)
= 0 + 15000 + 2500
= 17,500 ₹
```

**4. Reimbursed Amount (Sum of status='Reimbursed'):**
```
filter(c => c.status === 'Reimbursed')
= [{ amount: 15000, status: 'Reimbursed' }]
.reduce((sum, c) => sum + c.amount, 0)
= 0 + 15000
= 15,000 ₹
```

**Final Dashboard Display:**
```
Total Claimed:     ₹30,500
Pending Review:    1
Approved Amount:   ₹17,500
Reimbursed:        ₹15,000
```

**Key JavaScript Functions Used:**

1. **filter()** - Select claims matching condition
2. **reduce()** - Sum amounts into single value
3. **length** - Count items in array

**Why This Approach:**
- Recalculates fresh every time (no stale data)
- Easy to understand logic
- Efficient for small datasets
- Would need optimization for 100,000+ claims

---

## Question 6: How Did You Implement the Search and Filter Feature?

### Interview Question
*"Your 'All Claims' table has search by ID/name and filters by category and status. How does this work?"*

### Suggested Answer

**Filter Architecture:**
```html
<!-- Three filter inputs in HTML -->
<input id="search-claims-input" placeholder="Search by ID or name">
<select id="filter-category-select">
    <option value="ALL">All Categories</option>
    <option value="Travel">Travel</option>
    <option value="Meals">Meals</option>
</select>
<select id="filter-status-select">
    <option value="ALL">All Status</option>
    <option value="Pending">Pending</option>
    <option value="Approved">Approved</option>
</select>
```

**JavaScript Implementation:**
```javascript
renderAllClaimsTable: function(claims) {
    // Get user's current filter values
    const searchTerm = document.getElementById('search-claims-input').value.toLowerCase();
    const filterCategory = document.getElementById('filter-category-select').value;
    const filterStatus = document.getElementById('filter-status-select').value;
    
    // Apply all filters
    let filtered = claims.filter(claim => {
        // Search filter (ID or name)
        const matchesSearch = 
            claim.id.toLowerCase().includes(searchTerm) || 
            claim.empName.toLowerCase().includes(searchTerm);
        
        // Category filter
        const matchesCategory = 
            filterCategory === 'ALL' || claim.category === filterCategory;
        
        // Status filter
        const matchesStatus = 
            filterStatus === 'ALL' || claim.status === filterStatus;
        
        // Return true only if ALL conditions match (AND logic)
        return matchesSearch && matchesCategory && matchesStatus;
    });
    
    // Render filtered results
    renderTable(filtered);
}
```

**Filter Logic Flowchart:**
```
User input in search/filter
        ↓
Get current values (searchTerm, category, status)
        ↓
Loop through ALL claims
        ↓
For each claim, check THREE conditions:
    1. Search matches? (ID or name contains search term)
    2. Category matches? (category = selected OR all selected)
    3. Status matches? (status = selected OR all selected)
        ↓
If ALL 3 conditions true → Include in results
If ANY condition false → Skip this claim
        ↓
Display filtered claims in table
```

**Real Example:**

**Initial Data (4 claims):**
```
EXP-1001  | John   | Travel  | Pending
EXP-1002  | Alice  | Meals   | Approved
EXP-1003  | Bob    | Travel  | Approved
EXP-1004  | Carol  | Office  | Rejected
```

**Scenario: User searches for "john" and filters by Travel**
```
searchTerm = "john"
filterCategory = "Travel"
filterStatus = "ALL"

Check EXP-1001: John, Travel, Pending
  - matchesSearch = "john" in "john" → TRUE
  - matchesCategory = Travel === Travel → TRUE
  - matchesStatus = ALL (always true) → TRUE
  - Result: ✅ INCLUDE

Check EXP-1002: Alice, Meals, Approved
  - matchesSearch = "john" in "alice" → FALSE
  - Result: ❌ SKIP (failed search)

Check EXP-1003: Bob, Travel, Approved
  - matchesSearch = "john" in "bob" → FALSE
  - Result: ❌ SKIP (failed search)

Check EXP-1004: Carol, Office, Rejected
  - matchesSearch = "john" in "carol" → FALSE
  - Result: ❌ SKIP

Final Result: Only EXP-1001 displayed
```

**Event Listeners (Real-Time Updates):**
```javascript
// User types in search box
document.getElementById('search-claims-input')
    .addEventListener('input', () => {
        UI.renderAllClaimsTable(StorageService.getClaims());
        // Re-render instantly as user types
    });

// User changes category filter
document.getElementById('filter-category-select')
    .addEventListener('change', () => {
        UI.renderAllClaimsTable(StorageService.getClaims());
        // Re-render instantly when filter changes
    });

// User clicks clear filters button
document.getElementById('clear-filters-btn')
    .addEventListener('click', () => {
        // Reset all inputs to defaults
        document.getElementById('search-claims-input').value = '';
        document.getElementById('filter-category-select').value = 'ALL';
        document.getElementById('filter-status-select').value = 'ALL';
        // Show all claims again
        UI.renderAllClaimsTable(StorageService.getClaims());
    });
```

**Why This Design:**
- ✅ Filters work together (AND logic)
- ✅ Real-time update as user types
- ✅ Case-insensitive search (`.toLowerCase()`)
- ✅ Clear button to reset all filters
- ✅ No server round-trip needed

---

## Question 7: Explain Event Delegation and How You Use It for Dynamic Buttons

### Interview Question
*"I see you handle clicks on the 'Approve', 'Reject', 'Reimburse' buttons that are dynamically generated in your table. How does this work without adding listeners to each button?"*

### Suggested Answer

**The Problem with Dynamic Elements:**
```javascript
// This WON'T WORK for dynamically created buttons:
document.querySelector('.approve-claim-btn').addEventListener('click', () => {
    // This only works for button existing when page loads
    // New buttons added later won't have this listener!
});

// Why? The button doesn't exist when page loads
// Buttons are created when renderApprovalQueue() is called
```

**My Solution: Event Delegation**
```javascript
// Listen on document for clicks anywhere
document.addEventListener('click', (e) => {
    // Check if clicked element is an "Approve" button
    const approveBtn = e.target.closest('.approve-claim-btn');
    if (approveBtn) {
        const id = approveBtn.getAttribute('data-id');
        StorageService.updateClaimStatus(id, 'Approved');
        UI.refreshAll();
        UI.showToast(`Claim #${id} approved!`);
    }
});
```

**How `.closest()` Works:**
```html
<!-- Button is generated like this -->
<button class="btn approve-claim-btn" data-id="EXP-1001">Approve</button>

<!-- When clicked: -->
e.target                        ← Button element
e.target.closest('.approve-claim-btn')  ← Finds button itself
                               ← Returns the button
                               ← Now we can get data-id
```

**Event Delegation Flow:**
```
User clicks on approve button
        ↓
Browser fires 'click' event on that element
        ↓
Event bubbles UP to parent elements
        ↓
Document listener catches it
        ↓
Check: Does it have class 'approve-claim-btn'?
        ↓
If YES → Extract data-id and process
If NO → Check next condition
```

**Multiple Dynamic Buttons in One Listener:**
```javascript
document.addEventListener('click', (e) => {
    // Check for Approve button
    const approveBtn = e.target.closest('.approve-claim-btn');
    if (approveBtn) {
        const id = approveBtn.getAttribute('data-id');
        StorageService.updateClaimStatus(id, 'Approved');
    }
    
    // Check for Reject button (different class)
    const rejectBtn = e.target.closest('.open-reject-modal-btn');
    if (rejectBtn) {
        const id = rejectBtn.getAttribute('data-id');
        showRejectModal(id);
    }
    
    // Check for Reimburse button
    const reimburseBtn = e.target.closest('.reimburse-claim-btn');
    if (reimburseBtn) {
        const id = reimburseBtn.getAttribute('data-id');
        StorageService.updateClaimStatus(id, 'Reimbursed');
    }
});
```

**Why This Is Better:**

| Approach | Pros | Cons |
|---|---|---|
| Add listener to each button | Works perfectly | Memory heavy, breaks with dynamic elements |
| Event delegation (my way) | One listener for all buttons, works with dynamic elements | Slightly more complex to understand |

**Real-World Scenario:**
```
1. Page loads (no claims in table yet)
2. renderApprovalQueue() creates buttons dynamically
3. User clicks "Approve" button
4. Document listener catches click
5. Checks if clicked element is approve button → YES
6. Processes the approval
7. refreshAll() runs, deletes old table, creates new buttons
8. User clicks new "Approve" button
9. Same document listener still works!
   (No need to re-add listeners)
```

**Key Insight:**
You only need ONE listener on document, and it handles ALL dynamically created elements with the same class.

---

## Question 8: How Do Modals Work in Your Application? Show Me an Example.

### Interview Question
*"You have two modals in your application - one for showing claim details and one for rejection reason. How do they work?"*

### Suggested Answer

**Modal 1: Claim Details Modal**

**HTML Structure:**
```html
<div class="modal fade" id="claimDetailsModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Claim Details</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="claim-details-content">
                <!-- Dynamic content goes here -->
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
```

**JavaScript to Show Modal:**
```javascript
UI.showClaimDetails: function(id) {
    // Find claim by ID
    const claim = StorageService.getClaims().find(c => c.id === id);
    
    // Format HTML with claim data
    let detailsHTML = `
        <div class="row">
            <div class="col-6">
                <small class="text-muted">Claim ID</small>
                <p><strong>${claim.id}</strong></p>
            </div>
            <div class="col-6">
                <small class="text-muted">Amount</small>
                <p><strong>₹${claim.amount.toFixed(2)}</strong></p>
            </div>
        </div>
        ...more details...
    `;
    
    // Insert HTML into modal
    document.getElementById('claim-details-content').innerHTML = detailsHTML;
    
    // Show modal using Bootstrap
    const modal = new bootstrap.Modal(
        document.getElementById('claimDetailsModal')
    );
    modal.show();
}
```

**How User Interacts:**
```
User clicks "View" button on a claim
        ↓
Event listener catches click → gets claim ID
        ↓
UI.showClaimDetails(id) is called
        ↓
Claim data formatted as HTML
        ↓
HTML inserted into modal
        ↓
Modal.show() makes modal visible
        ↓
User sees claim details in popup
        ↓
User clicks "Close" or X button
        ↓
Bootstrap automatically hides modal
```

**Modal 2: Rejection Reason Modal**

**HTML (Interactive form):**
```html
<div class="modal" id="rejectReasonModal">
    <div class="modal-body">
        <p>Please provide a reason for rejecting this claim.</p>
        <textarea id="reject-reason-input" rows="4" 
                  placeholder="Enter rejection reason..."></textarea>
        <div id="reject-reason-error" class="alert alert-danger d-none">
            Please enter a rejection reason.
        </div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-danger" id="confirm-reject-btn">
            Confirm Rejection
        </button>
    </div>
</div>
```

**JavaScript for Rejection:**
```javascript
// Step 1: Manager clicks "Reject" button
const openRejectBtn = e.target.closest('.open-reject-modal-btn');
if (openRejectBtn) {
    const id = openRejectBtn.getAttribute('data-id');
    
    // Store claim ID globally
    AppState.rejectTargetId = id;
    
    // Update modal title with claim ID
    document.getElementById('reject-claim-id-display').innerText = `#${id}`;
    
    // Clear previous input
    document.getElementById('reject-reason-input').value = '';
    
    // Hide error message
    document.getElementById('reject-reason-error').classList.add('d-none');
    
    // Show modal
    const modal = new bootstrap.Modal(
        document.getElementById('rejectReasonModal')
    );
    modal.show();
}

// Step 2: User enters reason and clicks "Confirm Rejection"
document.getElementById('confirm-reject-btn').addEventListener('click', () => {
    const reason = document.getElementById('reject-reason-input').value.trim();
    const errorEl = document.getElementById('reject-reason-error');
    
    // Validation: reason required
    if (!reason) {
        errorEl.classList.remove('d-none');  // Show error
        return;  // Don't proceed
    }
    
    // Get claim ID (stored earlier)
    const id = document.getElementById('reject-target-id').value;
    
    // Update claim status with reason
    StorageService.updateClaimStatus(id, 'Rejected', { 
        rejectionReason: reason 
    });
    
    // Refresh UI
    UI.refreshAll();
    UI.showToast(`Claim #${id} has been Rejected.`, 'danger');
    
    // Close modal
    const modalEl = document.getElementById('rejectReasonModal');
    const modal = bootstrap.Modal.getInstance(modalEl);
    if (modal) modal.hide();
});
```

**Complete Workflow:**
```
1. Manager sees claim in approval queue
2. Clicks "Reject" button
   └─ Modal opens with text input
3. Enters rejection reason (e.g., "Budget exceeded")
4. Clicks "Confirm Rejection"
   ├─ Validates reason is not empty
   ├─ Updates claim status to 'Rejected'
   ├─ Stores rejection reason
   ├─ Refreshes dashboard
   ├─ Shows success toast
   └─ Closes modal
5. Claim disappears from approval queue
6. Claim shows as Rejected in All Claims
7. Details modal shows rejection reason
```

**Bootstrap Modal Features I Use:**
- `new bootstrap.Modal()` - Create modal instance
- `.show()` - Display modal
- `.hide()` - Hide modal
- `data-bs-dismiss="modal"` - Close button
- `.d-none` - Hide error message until needed

---

## Question 9: What Are the Main JavaScript Objects in Your Architecture?

### Interview Question
*"Your application seems to be organized with objects like StorageService, UI, Handlers, and AppState. Can you explain the purpose of each?"*

### Suggested Answer

**Application Architecture - Four Main Objects:**

**1. AppState (Global Application State)**
```javascript
const AppState = {
    activeTab: 'dashboard-view',     // Current view
    rejectTargetId: null,             // Claim being rejected
    statusChart: null,                // Chart instance
    categoryChart: null               // Chart instance
};
```
**Purpose**: Stores global variables and state
**When to Use**: When you need to share data across functions
**Example**: When opening reject modal, we store claim ID in AppState

---

**2. StorageService (Data Persistence Layer)**
```javascript
const StorageService = {
    KEY: 'expenseClaims',
    
    getDemoData() { return [...]; },
    getClaims() { /* Read from storage */ },
    addClaim(claim) { /* Add to storage */ },
    updateClaimStatus(id, status) { /* Update storage */ },
    resetData() { /* Restore demo data */ }
};
```
**Purpose**: ALL interaction with localStorage happens here
**When to Use**: Whenever you need to save/read data
**Key Principle**: Every object calls StorageService for data needs

**Why This Matters**: If backend needed later, we only change StorageService!

---

**3. UI (View Rendering Layer)**
```javascript
const UI = {
    renderDashboardStats() { /* Calculate & display stats */ },
    renderCharts(claims) { /* Create Chart.js graphs */ },
    renderAllClaimsTable(claims) { /* Show table */ },
    renderApprovalQueue() { /* Show pending claims */ },
    renderReimbursementQueue() { /* Show approved claims */ },
    showClaimDetails(id) { /* Show details modal */ },
    showToast(message) { /* Show notification */ },
    refreshAll() { /* Re-render everything */ }
};
```
**Purpose**: Renders all HTML views and updates display
**When to Use**: Whenever something needs to change on screen
**Key Function**: `refreshAll()` - called after every action to sync UI with data

**Example Flow**:
```
User clicks Approve
    ↓
Handlers catches click
    ↓
StorageService.updateClaimStatus() saves change
    ↓
UI.refreshAll() updates all views
    ├─ Dashboard stats recalculated
    ├─ Approval queue re-rendered
    ├─ Reimbursement queue re-rendered
    └─ Charts updated
```

---

**4. Handlers (Event Management Layer)**
```javascript
const Handlers = {
    init() {
        // Add event listeners when page loads
        // Form submit, button clicks, input changes, etc.
    },
    
    switchTab(viewId) {
        // Handle navigation between sections
    }
};
```
**Purpose**: Handles ALL user interactions
**When to Use**: For form submissions, button clicks, etc.
**Pattern**: Handlers → StorageService → UI

**Responsibilities**:
- Form validation
- Button click handling
- Tab switching
- Modal show/hide
- File upload preview

---

**How They Work Together:**

```
USER ACTION (click button)
        ↓
Handlers.init() (event listener)
        ↓
StorageService.updateClaimStatus()
        ↓
Data saved to localStorage
        ↓
UI.refreshAll()
        ↓
Display updated
```

**Real Example: User Approves Claim**

```javascript
// 1. Handlers catches the click
document.addEventListener('click', (e) => {
    const approveBtn = e.target.closest('.approve-claim-btn');
    if (approveBtn) {
        // 2. Extract claim ID
        const id = approveBtn.getAttribute('data-id');
        
        // 3. Call StorageService to update
        StorageService.updateClaimStatus(id, 'Approved');
        
        // 4. Call UI to refresh display
        UI.refreshAll();
        
        // 5. Show notification
        UI.showToast(`Claim #${id} approved!`, 'success');
    }
});
```

**Separation of Concerns:**

| Object | Responsibility | Example |
|---|---|---|
| AppState | Hold global state | activeTab, rejectTargetId |
| StorageService | Persist data | Read/write localStorage |
| UI | Display data | Render table, update stats |
| Handlers | Handle events | Click, submit, input |

**Why This Matters:**
- ✅ Easy to test (can test each layer separately)
- ✅ Easy to modify (change one layer without affecting others)
- ✅ Easy to scale (add features without restructuring)
- ✅ Clear responsibilities (no confusion)

---

## Question 10: How Would You Scale This Application to Handle 100,000 Claims?

### Interview Question
*"Right now your application stores data in localStorage with demo data. How would you modify this to handle enterprise scale with millions of records?"*

### Suggested Answer

**Current Limitations (Small Scale Only):**
```javascript
// All data in memory as JSON array
const claims = StorageService.getClaims();
// If 100,000 claims → 10MB+ data → localStorage might fail

// Every search/filter loops through all records
claims.filter(c => c.status === 'Pending');
// With 100,000 records → Slow!

// All data loaded on page load
// User has to wait for huge JSON parse
```

---

**Solution: Migrate to Backend**

**Phase 1: Add Backend Server**
```javascript
// Instead of localStorage, use API:

// Get claims from server (with pagination)
const getClaims = async (page = 1) => {
    const response = await fetch(
        `/api/claims?page=${page}&limit=50`
    );
    // Returns only 50 claims, not 100,000!
};

// Add new claim
const addClaim = async (claim) => {
    await fetch('/api/claims', {
        method: 'POST',
        body: JSON.stringify(claim)
    });
};

// Search with server-side filtering
const searchClaims = async (searchTerm) => {
    const response = await fetch(
        `/api/claims/search?q=${searchTerm}`
    );
    // Database does filtering, not JavaScript!
};
```

**Phase 2: Backend Technologies**
```
Frontend (Current)          Backend (New)
├─ React/Vue.js      ───────────► Node.js / Python / Java
├─ API calls                      │
└─ Display only                   └─► Database (PostgreSQL)
                                      ├─ 100M+ records
                                      ├─ Fast queries with indexes
                                      └─ Transactions

Additional Services:
├─ Authentication (JWT tokens)
├─ Authorization (RBAC)
├─ File Storage (S3, Google Cloud)
├─ Caching (Redis)
└─ Search (Elasticsearch)
```

**Phase 3: Specific Improvements**

**3A. Pagination (Load data in chunks)**
```javascript
// Instead of loading all 100,000:
// Load 50 at a time

const claims = await fetch('/api/claims?page=1&limit=50');
// Response: { data: [...50 claims...], total: 100000 }

// When user scrolls:
const claims = await fetch('/api/claims?page=2&limit=50');
// Load next 50
```

**3B. Caching (Reduce database queries)**
```
Redis Cache
├─ Store frequently accessed data
├─ Expire old data after 1 hour
└─ Reduces database load
```

**3C. Indexing (Speed up searches)**
```sql
-- Without index: scans all 100,000 records (slow)
-- With index: finds matching records instantly (fast)

CREATE INDEX idx_status ON claims(status);
CREATE INDEX idx_empId ON claims(empId);
```

**3D. Full-Text Search (Better searching)**
```javascript
// Current: search in memory
claims.filter(c => c.empName.includes(term))
// Slow with 100,000 records

// Better: Elasticsearch
const search = await fetch(
    '/api/search?q=john&type=employee'
);
// Searches indexed data in milliseconds
```

---

**Architecture for Scale:**

```
┌─────────────────┐
│  Web Client     │
│  (React/Vue)    │
└────────┬────────┘
         │
    (API calls)
         │
┌────────▼────────┐
│  API Server     │  (Node.js, Python)
│  (Validates)    │
└────────┬────────┘
         │
    (Queries)
         │
    ┌────┴────┬─────────┬──────────┐
    │          │         │          │
    ▼          ▼         ▼          ▼
┌────────┐ ┌──────┐ ┌────────┐ ┌─────────┐
│  Main  │ │Redis │ │Elastic │ │  File   │
│Database│ │Cache │ │Search  │ │Storage  │
└────────┘ └──────┘ └────────┘ └─────────┘
```

---

**What I Would Change:**

| Component | Current | Scalable |
|---|---|---|
| Storage | localStorage | PostgreSQL / MongoDB |
| Search | JavaScript filter | Elasticsearch |
| Data load | All records | Pagination |
| Caching | None | Redis |
| Auth | Role selector | Login + JWT |
| Files | Base64 in storage | AWS S3 / Google Cloud |
| Charts | Chart.js (all data) | Server pre-calculated |

---

**Timeline to Scale:**

**Week 1-2**: Build Node.js/Express API
**Week 3-4**: Add PostgreSQL database
**Week 5-6**: Implement authentication & authorization
**Week 7-8**: Add caching (Redis)
**Week 9-10**: Full-text search (Elasticsearch)
**Week 11+**: Performance testing, optimization

---

**Keeping Current Code Reusable:**

```javascript
// Current StorageService works with localStorage
// New LocalStorageService works same way
// Just different backend

// Using Adapter pattern:
const StorageService = isBrowser ? LocalStorageService : APIService;

// Handlers don't change!
// UI doesn't change!
// Only data layer changes
```

---

## Summary: Key Takeaways for Interview

1. **LocalStorage Persistence**: Shows data never gets lost
2. **Approval Workflow**: Demonstrates state management
3. **Authentication**: Shows awareness of security gaps
4. **Unique IDs**: Proves problem-solving skills
5. **Calculations**: Shows math + data manipulation
6. **Filtering**: Demonstrates complex logic
7. **Event Delegation**: Shows JavaScript patterns
8. **Modals**: UI/UX knowledge
9. **Architecture**: Clean code principles
10. **Scalability**: Strategic thinking

---

