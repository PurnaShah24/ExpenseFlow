# ExpenseFlow - Interview Cheat Sheet
## Quick Reference for Interview Demonstration

---

## 60-SECOND ELEVATOR PITCH

*"ExpenseFlow is a corporate expense management system built with HTML, CSS, JavaScript, and Bootstrap. It demonstrates clean architecture with three main layers - data management using localStorage, UI rendering, and event handling. The application implements a realistic approval workflow where employees submit claims, managers approve or reject them, and finance reimburses approved claims. The entire system persists data in the browser without requiring a backend, making it perfect for a portfolio project."*

---

## KEY FEATURES TO DEMONSTRATE (5 minutes)

1. **Submit Claim** (30 sec)
   - Show form with validation
   - Upload receipt image
   - Explain immediate Pending status

2. **Manager Approves** (1 min)
   - Switch to Manager role
   - Show approval queue
   - Approve a claim
   - Show it moves to Finance queue

3. **Manager Rejects** (1 min)
   - Click Reject button
   - Modal forces rejection reason
   - Explain business rule

4. **Finance Reimburses** (30 sec)
   - Switch to Finance role
   - Reimburse an approved claim
   - Show it removes from queue

5. **Dashboard Updates** (30 sec)
   - Show all stats update
   - Explain calculations
   - Show charts

6. **Data Persists** (30 sec)
   - Refresh browser
   - All data still there
   - Show DevTools localStorage

---

## 3 BUGS YOU FOUND & FIXED ✅

### Bug #1: Duplicate Claim IDs (CRITICAL)
```
Problem:  Math.random() * 9000 could generate same ID twice
Solution: Use Date.now() + random
Result:   Virtually impossible to duplicate
```
**How to Explain**: "I realized that with multiple concurrent claims, simple random numbers could collide. I used the millisecond timestamp as the primary key, making duplicates virtually impossible."

### Bug #2: Invalid CSS (MINOR)
```
Problem:  border: 1px border (wrong syntax)
Solution: border: 1px solid (correct syntax)
Result:   Receipt images render with proper border
```
**How to Explain**: "Found CSS syntax error where 'border' was used as a style property instead of 'solid'. Fixed the border declaration and added max-width for mobile."

### Bug #3: Mobile Modal Issue (MEDIUM)
```
Problem:  Modal backdrop z-index behind sidebar on mobile
Solution: Add media query to fix z-index for small screens
Result:   Modal now visible and functional on mobile
```
**How to Explain**: "On mobile, the modal backdrop had lower z-index than sidebar, making it invisible. Added media query to properly layer elements on small screens."

---

## TECHNICAL ARCHITECTURE IN 3 SENTENCES

"The application has three main JavaScript objects: **StorageService** manages all data with localStorage, **UI** renders views and recalculates statistics, and **Handlers** listens for user events and coordinates between the other two. When a user submits a claim, the Handlers catches the submit event, calls StorageService to save data, then calls UI.refreshAll() to update the display. This separation of concerns makes the code clean and maintainable."

---

## LOCALSTORESAGE EXPLAINED SIMPLY

**What**: Browser's built-in storage (like a hard drive on your computer)
**How**: Saves data as JSON strings
**Why**: Data persists even after closing the browser
**Limit**: ~5-10MB per website
**Perfect for**: Demo projects without a server

**Show**: Open DevTools (F12) → Application → LocalStorage → Click domain → See "expenseClaims" key with JSON array of claims

---

## APPROVAL WORKFLOW IN ONE DIAGRAM

```
Employee Creates
       ↓
    [Pending]
       ↓
Manager Reviews
    ↙     ↘
[Approved] [Rejected]
    ↓         (with reason)
Finance
Reimburses
    ↓
[Reimbursed]
```

**Business Rules Enforced**:
1. New claims ALWAYS start as Pending
2. Only Pending claims shown to Manager
3. Rejection REQUIRES a reason (validated)
4. Only Approved claims shown to Finance
5. Only Reimbursed claims are final

---

## WHAT'S GOOD ABOUT THIS PROJECT

✅ **Demonstrates Real Skills**
- Clean code architecture (separation of concerns)
- Data persistence (localStorage)
- Workflow logic (approval process)
- Filtering & search (real-time)
- Responsive design (works on mobile)
- Event handling (event delegation)

✅ **Shows Problem-Solving**
- Found and fixed bugs
- Tested thoroughly
- Thought about edge cases
- Verified business logic

✅ **Shows Professional Practices**
- Meaningful variable names
- Organized code structure
- Input validation
- User feedback (toast notifications)
- Modal dialogs for confirmations

✅ **Shows Awareness of Limitations**
- Knows localStorage has limits
- Understands need for backend
- Aware of security gaps (no auth)
- Knows how to scale to production

---

## WHAT'S LIMITED (Be Honest)

⚠️ **No Authentication**
- Role selector is just UI
- Needs real login for production
- No security enforcement

⚠️ **No Backend**
- Can't share data between devices
- Doesn't scale to enterprise
- Limited to 5-10MB localStorage

⚠️ **No Advanced Features**
- No email notifications
- No audit logging
- No PDF export
- No date range filtering

**BUT**: "These are intentional simplifications for a portfolio project. In a production system, I would add a Node.js backend with database, authentication, and proper file storage."

---

## MOST LIKELY INTERVIEW QUESTIONS

### Q1: "Walk me through your application"
**Answer**: "Start with Submit Claim tab, fill form, explain Pending status, switch to Manager view, approve/reject, show Finance queue, reimburse, show dashboard updates, refresh to prove persistence"

### Q2: "What bugs did you find?"
**Answer**: "Three bugs: (1) Duplicate claim IDs from simple random, (2) Invalid CSS border syntax, (3) Modal z-index issue on mobile. Explain each fix briefly."

### Q3: "How does data persist?"
**Answer**: "I use browser localStorage with a unique key 'expenseClaims'. When form submits, data is saved as JSON string. On page load, data is retrieved. Works great for demo, but would need database for production."

### Q4: "Explain your architecture"
**Answer**: "Three objects - StorageService handles data, UI renders views, Handlers manages events. When user acts, Handlers calls StorageService, which calls UI.refreshAll(). Clean separation of concerns."

### Q5: "How would you scale this?"
**Answer**: "Add Node.js backend with PostgreSQL database. Implement pagination to load 50 claims at a time instead of all. Add Elasticsearch for better search. Add Redis caching. This would handle millions of records."

### Q6: "What's the biggest limitation?"
**Answer**: "No real authentication. Anyone can switch roles. For production, I'd implement login system with backend session management and role-based access control."

### Q7: "Show me your code quality"
**Answer**: "Show clean variable names, good separation of concerns, DRY principle, proper error handling for validation, comments on complex logic."

### Q8: "How did you test this?"
**Answer**: "Manual testing - submitted claims, tested each status transition, verified dashboard calculations, tested search/filters, confirmed data persists after refresh, tested on mobile."

### Q9: "What would you add next?"
**Answer**: "Backend API, authentication, database, pagination, email notifications, PDF export, advanced reporting, audit logging."

### Q10: "Why this tech stack?"
**Answer**: "HTML/CSS/JavaScript are fundamental web technologies. Bootstrap for responsive design without complexity. LocalStorage for MVP without backend. Chart.js for visualizations. Everything can be understood and explained by a beginner."

---

## DEMO SCRIPT (5 minutes)

### [00:00-01:00] Initial View
"Here's the ExpenseFlow dashboard. It shows total claimed amount, pending claims, approved amount, and reimbursed amount. The sidebar has navigation to different views."

### [01:00-02:00] Submit Claim
"Let me submit a new claim. I'll click 'Submit Claim' tab, fill in employee name, ID, category, amount, upload a receipt. Click submit. Notice the claim appears in the All Claims table with Pending status."

### [02:00-03:00] Approval Workflow
"Now I'll switch to Manager view using the role selector. Go to Approvals queue. I'll approve this claim. See it disappears from here and appears in the Finance Reimbursements queue."

### [03:00-04:00] Rejection
"For this claim, I'll click Reject. Notice the modal requires a rejection reason - that's business logic enforcement. I'll enter 'Budget exceeded' and click Confirm. The claim now shows Rejected status."

### [04:00-05:00] Persistence
"Let me refresh the browser. All data persists! Open DevTools, go to LocalStorage, show the expenseClaims key with JSON array. Data survives refresh because it's stored in the browser."

---

## THINGS TO SHOW IN DEVTOOLS

### F12 → Application Tab
```
Local Storage
└── (Current Domain)
    └── expenseClaims: [
        {
          "id": "EXP-1695894567892-342",
          "empName": "John Doe",
          "amount": 5000,
          "status": "Pending",
          ...
        },
        { next claim... }
      ]
```

### F12 → Console Tab
```javascript
// Type this to see claims:
StorageService.getClaims()

// Returns: [Array of claims]

// See specific claim:
StorageService.getClaims()[0]

// Returns: { id: "EXP-...", empName: "...", ... }
```

### F12 → Network Tab
```
No requests to server
(Everything runs locally!)

This shows:
✓ No API calls
✓ No backend server needed
✓ Pure frontend technology
```

---

## CONFIDENCE BOOSTERS

### Things You Know Well
✅ Entire codebase (wrote it)
✅ How approval workflow works (designed it)
✅ Why you made each decision (deliberate choices)
✅ Every bug and fix (found them yourself)
✅ How to test it (tested thoroughly)
✅ How to explain it (clear architecture)

### Things to Acknowledge
⚠️ "This is an MVP for a portfolio project"
⚠️ "In production, I would add X..."
⚠️ "For larger scale, I would change to..."
⚠️ "I'm aware this doesn't have authentication..."

---

## RED FLAGS TO AVOID

❌ **Don't say**: "I don't know" (you wrote it!)
✅ **Instead say**: "Let me show you in the code"

❌ **Don't say**: "This is perfect" (it has limits)
✅ **Instead say**: "This works great for an MVP. Here's how I'd scale it..."

❌ **Don't say**: "I copied this from somewhere" (if you did)
✅ **Instead say**: "I learned this pattern from documentation and adapted it"

❌ **Don't say**: "I haven't tested this" (you should have)
✅ **Instead say**: "I tested this with these scenarios..."

---

## NOTES TO MEMORIZE

**Unique Claim ID Formula**
```javascript
'EXP-' + Date.now() + '-' + Math.random() * 1000
// Explains: timestamp unique per millisecond, random fallback
// Why: Prevents duplicates unlike simple random numbers
```

**Filter Logic**
```javascript
// Search AND Category AND Status all must match
// Uses array.filter() with multiple conditions
// Real-time as user types using event listeners
```

**Dashboard Calculation**
```javascript
// Sum using reduce()
// Count using filter().length
// Recalculates on every refresh
```

---

## 3 STRONG TALKING POINTS

### Point 1: "Clean Architecture"
"I separated concerns into three objects - data (StorageService), presentation (UI), and events (Handlers). This makes code maintainable and testable. If I needed to change where data is stored, I only modify StorageService, not the entire app."

### Point 2: "Business Logic"
"The approval workflow enforces real business rules - claims must be Pending before approval, rejection requires reason, only approved claims can be reimbursed. This shows I understand not just coding, but domain logic."

### Point 3: "Problem-Solving"
"I found three bugs and fixed them systematically. The most important was the duplicate claim ID problem - simple random numbers could collide. I solved it with Date.now() timestamp. This shows I don't just code, I debug and improve."

---

## FINAL CHECKLIST (Before Interview)

- [ ] Open expenseflow_FIXED.html and test it works
- [ ] Go through demo script once
- [ ] Understand all 3 bugs and fixes
- [ ] Know answers to 10 questions
- [ ] Can explain architecture in 2 minutes
- [ ] Have DevTools open to show localStorage
- [ ] Test on mobile (< 768px) to show responsiveness
- [ ] Show search/filter in action
- [ ] Demonstrate rejection modal with reason
- [ ] Explain why chose this tech stack
- [ ] Be ready to explain limitations honestly
- [ ] Have talking points memorized

---

## INTERVIEW DAY MINDSET

✅ **Confidence**: "I built this entire system"
✅ **Honesty**: "This is a portfolio MVP, not production ready"
✅ **Enthusiasm**: "I learned a lot building this"
✅ **Humility**: "I'm aware of what needs improvement"
✅ **Clarity**: "Let me show you how it works"

---

## CONTACT POINTS

If they ask "Do you have this live somewhere?"
- "I can deploy it to Netlify in 2 minutes" OR
- "Here's the file, you can run it locally" OR  
- "I'll send you a GitHub link"

If they ask "Can you modify it now?"
- "Absolutely, I have the code right here"
- Show how quick it is to make small changes

If they ask "Questions for us?"
- "What's the tech stack for your projects?"
- "What's the onboarding like for new developers?"
- "How do you handle code reviews?"

---

## REMEMBER

You built something REAL. It works. You understand every line. You found and fixed bugs. You tested it thoroughly.

You're not just a coder - you're a software engineer who can:
- ✅ Architect systems
- ✅ Write clean code
- ✅ Debug problems
- ✅ Test thoroughly
- ✅ Explain decisions
- ✅ Acknowledge limitations
- ✅ Plan for scale

That's what employers want.

---

**Good luck! You've got this.** 🚀

